# MWE Marketplace — Android project

Native Android app starter for MWE Marketplace. It includes farm, clothing/accessories and services categories, plus direct call and WhatsApp contact buttons for the three MWE numbers.

## Build the APK using only an Android phone (GitHub Actions)

No laptop is required, but a GitHub account and internet access are required.

1. Install/open the GitHub mobile app, or visit github.com in your phone browser and sign in.
2. Create a new **public** or **private** repository named `mwe-marketplace` (do not add a README, licence or gitignore).
3. Extract this ZIP on your phone using your Files app or an archive app.
4. Upload the *contents* of the extracted folder to the repository, preserving folder structure. Make sure `.github/workflows/build-apk.yml` is included. Some file pickers hide `.github`; if so, use GitHub's web upload or a file manager that shows hidden files.
5. In the repository, open **Actions**. If prompted, enable workflows.
6. Select **Build MWE Marketplace APK** and tap **Run workflow**.
7. Wait for the workflow to finish successfully. Open that run and find **Artifacts**.
8. Download `MWE-Marketplace-debug-apk`, extract it, then tap `app-debug.apk` to install. Android may ask you to allow installs from that file manager.

## App details

- App name: MWE Marketplace
- Application ID: zm.mwe.marketplace
- Minimum Android: Android 6.0 (API 23)
- Contact numbers configured: 0770791836, 0779155188, 0773331270
- WhatsApp links use Zambia country code +260.

## Before distributing publicly

Verify the phone numbers and WhatsApp accounts on the target phone. Add real product photos, current prices and stock details. This first version is a contact/catalogue app only; it does not yet provide online payments, order tracking, stock management, or seller accounts. The debug APK is suitable for initial testing; a signed release build is recommended for a public production launch.
