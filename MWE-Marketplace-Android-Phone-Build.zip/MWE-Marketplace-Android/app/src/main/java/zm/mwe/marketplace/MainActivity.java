package zm.mwe.marketplace;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    final String[] phones = {"0770791836", "0779155188", "0773331270"};
    final String[] whatsapp = {"260770791836", "260779155188", "260773331270"};
    LinearLayout page;
    int green = Color.rgb(27, 94, 55);
    int ink = Color.rgb(30, 39, 33);
    int pale = Color.rgb(239, 247, 240);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(green);
        getWindow().setNavigationBarColor(Color.BLACK);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(22), dp(20), dp(30));
        page.setBackgroundColor(Color.WHITE);
        scroll.addView(page);
        setContentView(scroll);
        buildHome();
    }

    void buildHome() {
        page.removeAllViews();
        TextView brand = new TextView(this);
        brand.setText("MWE MARKETPLACE");
        brand.setTextColor(green); brand.setTextSize(27); brand.setTypeface(null, Typeface.BOLD);
        page.addView(brand);
        TextView motto = new TextView(this);
        motto.setText("MWE FARM  •  Growing Together, Feeding the Future");
        motto.setTextColor(ink); motto.setTextSize(13);
        motto.setPadding(0, dp(5), 0, dp(18)); page.addView(motto);

        TextView hero = new TextView(this);
        hero.setText("Good products. Reliable services. Direct contact.");
        hero.setTextSize(22); hero.setTypeface(null, Typeface.BOLD); hero.setTextColor(Color.WHITE);
        hero.setPadding(dp(18), dp(22), dp(18), dp(22)); hero.setBackgroundColor(green);
        page.addView(hero);

        heading("Shop by category");
        category("🐓  Farm products", "Chickens, pigs, goats, vegetables and other farm produce.");
        category("👗  Clothing & accessories", "Women's clothing, shoes, bags and accessories.");
        category("🧰  Services", "Ask us about available services and current offers.");

        heading("How to order");
        paragraph("Choose what you are interested in, then contact MWE directly by WhatsApp or phone. Ask for current availability, prices, delivery and collection details. Product listings and prices are confirmed directly with us.");

        heading("Contact MWE");
        paragraph("Call or WhatsApp any of the numbers below. WhatsApp opens with a ready-made enquiry message.");
        for (int i = 0; i < phones.length; i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            row.setBackgroundColor(pale);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.setMargins(0, dp(5), 0, dp(5)); page.addView(row, rp);
            TextView number = new TextView(this);
            number.setText(phones[i]); number.setTextColor(ink); number.setTextSize(17);
            number.setTypeface(null, Typeface.BOLD); row.addView(number);
            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(actions);
            Button call = new Button(this); call.setText("Call");
            call.setOnClickListener(v -> dial(phones[index]));
            Button chat = new Button(this); chat.setText("WhatsApp");
            chat.setOnClickListener(v -> message(whatsapp[index]));
            actions.addView(call, new LinearLayout.LayoutParams(0, dp(48), 1));
            actions.addView(chat, new LinearLayout.LayoutParams(0, dp(48), 1));
        }

        TextView footer = new TextView(this);
        footer.setText("MWE MARKETPLACE\nOwned and operated by MWE. Prices and availability may change; confirm before payment.");
        footer.setGravity(Gravity.CENTER); footer.setTextColor(Color.GRAY); footer.setTextSize(12);
        footer.setPadding(0, dp(25), 0, dp(10)); page.addView(footer);
    }

    void heading(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(19);
        t.setTypeface(null, Typeface.BOLD); t.setTextColor(green);
        t.setPadding(0, dp(22), 0, dp(8)); page.addView(t);
    }
    void paragraph(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(15);
        t.setTextColor(ink); t.setLineSpacing(dp(3), 1f); page.addView(t);
    }
    void category(String title, String desc) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(13), dp(15), dp(13)); card.setBackgroundColor(pale);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5)); page.addView(card, p);
        TextView a = new TextView(this); a.setText(title); a.setTextSize(17);
        a.setTypeface(null, Typeface.BOLD); a.setTextColor(ink); card.addView(a);
        TextView b = new TextView(this); b.setText(desc); b.setTextSize(14);
        b.setTextColor(ink); b.setPadding(0, dp(4), 0, 0); card.addView(b);
        Button ask = new Button(this); ask.setText("Enquire about this");
        ask.setOnClickListener(v -> message(whatsapp[0], "Hello MWE Marketplace, I am interested in " + title.replaceAll("^.*  ", "") + ". Please share available options and prices."));
        card.addView(ask);
    }
    void dial(String n) {
        try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + n))); }
        catch (Exception e) { toast("Unable to open the phone app."); }
    }
    void message(String n) { message(n, "Hello MWE Marketplace, I would like to enquire about your products or services."); }
    void message(String n, String msg) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + n + "?text=" + Uri.encode(msg)));
            startActivity(i);
        } catch (Exception e) { toast("WhatsApp could not be opened. Please call one of the listed numbers."); }
    }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
